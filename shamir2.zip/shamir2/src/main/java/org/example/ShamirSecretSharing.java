package org.example;

import org.json.JSONObject;
import org.json.JSONException;
import java.util.HashMap;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class ShamirSecretSharing {

    public static int decodeValue(String value, int base) {
        return Integer.parseInt(value, base);
    }

    public static Map<Integer, Integer> parseInput(String inputJson) {
        Map<Integer, Integer> roots = new HashMap<>();

        try {
            JSONObject jsonObject = new JSONObject(inputJson);
            JSONObject keys = jsonObject.getJSONObject("keys");

            for (String key : keys.keySet()) {
                if (key.equals("n") || key.equals("k")) {
                    continue;
                }

                JSONObject rootObject = keys.getJSONObject(key);
                int base = rootObject.getInt("base");
                String valueStr = rootObject.getString("value");
                int x = Integer.parseInt(key); // x is the key
                int y = decodeValue(valueStr, base); // y is the decoded value

                roots.put(x, y);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return roots;
    }

    public static double lagrangeInterpolation(Map<Integer, Integer> roots) {
        Integer[] xValues = roots.keySet().toArray(new Integer[0]);
        Integer[] yValues = roots.values().toArray(new Integer[0]);

        double constantTerm = 0.0;

        for (int i = 0; i < xValues.length; i++) {
            int xi = xValues[i];
            int yi = yValues[i];
            double li = 1.0;
            for (int j = 0; j < xValues.length; j++) {
                if (i != j) {
                    int xj = xValues[j];
                    li *= (0 - xj) / (double) (xi - xj);
                }
            }

            constantTerm += yi * li;
        }

        return constantTerm;
    }

    public static void findConstantTerm(String inputJson) {
        Map<Integer, Integer> roots = parseInput(inputJson);
        double constantTerm = lagrangeInterpolation(roots);
        System.out.printf("The constant term (c) is: %.2f%n", constantTerm);
    }

    public static void main(String[] args) {
        String filePath = "/Users/v-dhyaneswar.bachu/renderingTool/shamir2/src/main/java/org/example/input.json";

        try {
            String inputJson = new String(Files.readAllBytes(Paths.get(filePath)));
            findConstantTerm(inputJson);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
